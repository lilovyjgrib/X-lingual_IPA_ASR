library(ggplot2)
library(dplyr)
library(patchwork) #for wrapping two plots in one
library(ggpubr)


#install.packages("ggplot2")



#=======import data==========================
Poem_Tonemes <- read.delim("Ijala_Esa_Speech/Pitch_Poetry_Toneme_2.txt")
Poem_Formants<- read.delim("Ijala_Esa_Speech/Formant_Poetry_Vowels.txt")
Poem_Spectral <- read.delim("Ijala_Esa_Speech/Spectral_Poetry_Vowels.txt")
Poem_Tones <- read.delim("Ijala_Esa_Speech/Tones_Poetry.txt")
Poem_Intensity <- read.delim("Ijala_Esa_Speech/Intensity_Poetry_Vowels.txt")
Poem_Tremor_Duration <- read.delim("Ijala_Esa_Speech/Tremor_Duration.txt")
Poem_Tremor_Frequency <- read.delim("Ijala_Esa_Speech/Tremor_Analysis.txt")

#===normalise F0 of tone based on vowels===========

Poem_Tonemes$Vowels <- factor(Poem_Tonemes$Vowels)

subjs <- levels(Poem_Tonemes$Vowels)
Poem_Tonemes$normF0_25 <- 0
Poem_Tonemes$normF0_50 <- 0
Poem_Tonemes$normF0_75 <- 0
for (s in 1:length(subjs))
{
  sub <- subset(Poem_Tonemes, Vowels == subjs[s])
  Poem_Tonemes[Poem_Tonemes$Vowels == subjs[s],]$normF0_25 <- (sub$F0_25 - mean(sub$F0_25))/ sd(sub$F0_25)
  Poem_Tonemes[Poem_Tonemes$Vowels == subjs[s],]$normF0_50 <- (sub$F0_50 - mean(sub$F0_50))/ sd(sub$F0_50)
  Poem_Tonemes[Poem_Tonemes$Vowels == subjs[s],]$normF0_75 <- (sub$F0_75 - mean(sub$F0_75))/ sd(sub$F0_75)
}





#=======replace_symbols==========================
remapping1 <- c(i="i", u ="u", e = "e", o="o", E="ɛ", O="ɔ", a="a")

Poem_Formants$Vowels <- remapping1[as.character(Poem_Formants$Vowel)]


remapping2 <- c(i="i", u ="u", e = "e", o="o", E="ɛ", O="ɔ", a="a")

Poem_Spectral$Vowels <- remapping2[as.character(Poem_Spectral$Vowel)]


remapping5 <- c(i="i", u ="u", e = "e", o="o", E="ɛ", O="ɔ", a="a")

Poem_Intensity$Vowels <- remapping5[as.character(Poem_Intensity$Vowel)]



#===============================wrapping in boxplot in ggpubr======================
library("ggpubr")



#begin here for better resolution
tiff("Formant_plot.tiff", units="in", width=5, height=4, res=400)
#begin: insert ggplot code (this changes the solution to a better)


poem_f1 <- ggboxplot(Poem_Formants, x = "Modes", y = "F1_50",
                     palette = "Greys", font.xtickslab = c(8), font.ytickslab = c(8), xtickslab.rt = 90, font.x=c(8), font.y=c(8),
                     add = "jitter", color= "grey", facet.by = "Vowels", ylim = c(190, 1000), panel.labs.font = list(size ="10"),
                     short.panel.labs = TRUE) + labs(x = "Modes", y = "F1 (Hertz)")+geom_boxplot()



poem_f2 <- ggboxplot(Poem_Formants, x = "Modes", y = "F2_50",
                     palette = "Greys", font.xtickslab = c(8), font.ytickslab = c(8),  xtickslab.rt = 90, font.x=c(8), font.y=c(8),
                     add = "jitter", color= "grey", facet.by = "Vowels", panel.labs.font = list(size ="10"),
                     short.panel.labs = TRUE) + labs(x = "Modes", y = "F2 (Hertz)")+geom_boxplot()




#wrap_plots(pout_dag2, pout_dag1) this is an alternative way to wrap plots with library(patchwork)



combined <- poem_f1 + poem_f2  & theme(axis.title=element_text(size=12), legend.position = "bottom")
combined + plot_layout(guides = "collect")




dev.off()
##end here for better resolution facet.by = "Vowel"






#begin here for better resolution
tiff("CPP_Ham_plot.tiff", units="in", width=5, height=4, res=400)
#begin: insert ggplot code (this changes the solution to a better)


poem_cpp <- ggboxplot(Poem_Spectral, x = "Modes", y = "CPP",
                      palette = "Greys", font.xtickslab = c(8), font.ytickslab = c(8), xtickslab.rt = 90, font.x=c(8), font.y=c(8),
                      add = "jitter", color= "grey", facet.by = "Vowels", panel.labs.font = list(size ="10"),
                      short.panel.labs = TRUE) + labs(x = "Modes", y = "CPP (dB)")+geom_boxplot()



poem_ham <- ggboxplot(Poem_Spectral, x = "Modes", y = "Hammarberg_index",
                      palette = "Greys", font.xtickslab = c(8), font.ytickslab = c(8),  xtickslab.rt = 90, font.x=c(8), font.y=c(8),
                      add = "jitter", color= "grey", facet.by = "Vowels", panel.labs.font = list(size ="10"),
                      short.panel.labs = TRUE) + labs(x = "Modes", y = "Hammarberg Index (dB)")+geom_boxplot()




#wrap_plots(pout_dag2, pout_dag1) this is an alternative way to wrap plots with library(patchwork)



combined <- poem_cpp + poem_ham  & theme(axis.title=element_text(size=12), legend.position = "bottom")
combined + plot_layout(guides = "collect")




dev.off()
##end here for better resolution facet.by = "Vowel"



#begin here for better resolution
tiff("intensity_energy_plot.tiff", units="in", width=5, height=4, res=400)
#begin: insert ggplot code (this changes the solution to a better)


poem_intensity_out <- ggboxplot(Poem_Intensity, x = "Modes", y = "mean_intensity",
                                palette = "Greys", font.xtickslab = c(8), font.ytickslab = c(8),  xtickslab.rt = 90, font.x=c(8), font.y=c(8),
                                add = "jitter", color= "grey", facet.by = "Vowels", panel.labs.font = list(size ="10"),
                                short.panel.labs = TRUE) + labs(x = "Modes", y = "Intensity (dB)")+geom_boxplot()


poem_energy <- ggboxplot(Poem_Spectral, x = "Modes", y = "energy_below_500Hz",
                         palette = "Greys", font.xtickslab = c(8), font.ytickslab = c(8),  xtickslab.rt = 90, font.x=c(8), font.y=c(8),
                         add = "jitter", color= "grey", facet.by = "Vowels", panel.labs.font = list(size ="10"),
                         short.panel.labs = TRUE) + labs(x = "Modes", y = "Energy below 500Hz (dB)")+geom_boxplot()


combined <- poem_intensity_out + poem_energy  & theme(axis.title=element_text(size=12), legend.position = "bottom")
combined + plot_layout(guides = "collect")


dev.off()
##end here for better resolution



##begin here for better resolution
tiff("duration_plot.tiff", units="in", width=5, height=4, res=400)
#begin: insert ggplot code (this changes the solution to a better)

poem_duration_out <- ggboxplot(subset(Poem_Formants, Vowel %in% c("a", "e", "E", "i", "o", "O", "u")), x = "Modes", y = "Duration",
                               palette = "Greys", font.xtickslab = c(8), font.ytickslab = c(8),  xtickslab.rt = 90, font.x=c(8), font.y=c(8),
                               add = "jitter", color= "grey", facet.by = "Vowels", panel.labs.font = list(size ="10"), ylim=c(50, 300),
                               short.panel.labs = TRUE) + labs(x = "Modes", y = "Duration(ms)")+geom_boxplot()


poem_duration_out

dev.off()
##end here for better resolution

#==========tonemes===f0===plot==================

#begin here for better resolution
tiff("f0_tonemes_seq_plot.tiff", units="in", width=5, height=4, res=400)
#begin: insert ggplot code (this changes the solution to a better)


poem_f025_out <- ggboxplot(subset(Poem_Tonemes, Toneme %in% c("L", "M", "H")), x = "Modes", y = "F0_25",
                           palette = "Greys", font.xtickslab = c(8), font.ytickslab = c(8),  xtickslab.rt = 90, font.x=c(8), font.y=c(8),
                           add = "jitter", color= "grey", facet.by = "Toneme", panel.labs.font = list(size ="10"), ylim=c(50, 350),
                           short.panel.labs = TRUE) + labs(x = "Modes", y = "F0(Hz) at 25% Interval")+geom_boxplot()


poem_f050_out <- ggboxplot(subset(Poem_Tonemes, Toneme %in% c("L", "M", "H")), x = "Modes", y = "F0_50",
                           palette = "Greys", font.xtickslab = c(8), font.ytickslab = c(8),  xtickslab.rt = 90, font.x=c(8), font.y=c(8),
                           add = "jitter", color= "grey", facet.by = "Toneme", panel.labs.font = list(size ="10"), ylim=c(50, 350),
                           short.panel.labs = TRUE) + labs(x = "Modes", y = "F0(Hz) at 50% Interval")+geom_boxplot()


poem_f0750_out <- ggboxplot(subset(Poem_Tonemes, Toneme %in% c("L", "M", "H")), x = "Modes", y = "F0_75",
                           palette = "Greys", font.xtickslab = c(8), font.ytickslab = c(8),  xtickslab.rt = 90, font.x=c(8), font.y=c(8),
                           add = "jitter", color= "grey", facet.by = "Toneme", panel.labs.font = list(size ="10"), ylim=c(50, 350),
                           short.panel.labs = TRUE) + labs(x = "Modes", y = "F0(Hz) at 75% Interval")+geom_boxplot()

ggarrange(poem_f025_out, poem_f050_out, poem_f0750_out, ncol = 2, nrow = 2)


dev.off()
##end here for better resolution



#============vibrato analysis===============

##begin here for better resolution
tiff("tremor_plot.tiff", units="in", width=5, height=4, res=400)
#begin: insert ggplot code (this changes the solution to a better)

poem_tremor_duration <- ggerrorplot(Poem_Tremor_Duration, x = "Modes",  y = "Duration",
                                    add = "mean", error.plot = "errorbar")+labs(x = "Modes", y = "Duration(ms)")+theme_bw()


poem_tremor_freq <- ggdensity(Poem_Tremor_Frequency, x = "FTrF_Hz", fill = "grey") +
  scale_x_continuous(limits = c(1, 7)) +
  stat_overlay_normal_density(color = "black", linetype = "dashed")+labs(x = "Vibrato Rate (Hz)", y = "Density")+theme_bw()



ggarrange(poem_tremor_duration, poem_tremor_freq, ncol = 2, nrow = 1, labels="auto")


dev.off()
##end here for better resolution

#==========line plots=======================================

remapping3 <- c(Line1="Line 1", Line2 ="Line 2", Line3 = "Line 3", Line4 ="Line 4", Line5="Line 5")

Poem_Tones$Lines <- remapping3[as.character(Poem_Tones$Line)]



#begin here for better resolution
tiff("tone_plot.tiff", units="in", width=5, height=4, res=400)
#begin: insert ggplot code (this changes the solution to a better)

ggplot(subset(Poem_Tones, Line %in% c("Line1", "Line2", "Line3", "Line4")), aes(x=Time_Sequence, y=F0, group=Modes, color=Modes)) +
  geom_smooth(method = "auto", se=T) +
  scale_colour_grey()+
  facet_wrap(vars(Lines))+
  labs(x = "Normalised time for tone sequences",
       y = "F0(Hertz)", color="Modes") +
  theme_bw() +
  theme(axis.text.x = element_text(colour = "grey20", size = 8, angle = 90, hjust = 0.5, vjust = 0.5),
        axis.text.y = element_text(colour = "grey20", size = 8),
        strip.text = element_text(face = "italic"),
        text = element_text(size = 12))

dev.off()
##end here for better resolution





#=======================mean,median, standard deviation=============
library(plyr)
library(doBy)

Poem_Tonemes


Poem_Tones_sum <- ddply(Poem_Tones, c("Time_Sequence", "Modes", "Lines"), summarise,
                        F0_mean = mean(F0)
)


Poem_Tonemes_25sum <- ddply(Poem_Tonemes, c("Toneme", "Modes"), summarise,
                            F0_mean= mean(normF0_25),
                            F0_sd = sd(normF0_25)
)

Poem_Tonemes_50sum <- ddply(Poem_Tonemes, c("Toneme", "Modes"), summarise,
                            F0_mean= mean(normF0_50),
                            F0_sd = sd(normF0_50)
)


Poem_Tonemes_75sum <- ddply(Poem_Tonemes, c("Toneme", "Modes"), summarise,
                            F0_mean= mean(normF0_75),
                            F0_sd = sd(normF0_75)
)

Poem_Tones_sum
Poem_Tonemes_25sum
Poem_Tonemes_50sum
Poem_Tonemes_75sum

#==================mutate the output of data_sum===============
library("tidyr")


Poem_Tones_corr <- pivot_wider(Poem_Tones_sum, names_from = "Modes",
                               values_from = "F0_mean")

View(Poem_Tones_corr)


#===========calculate Correlation Test Between Two Variables====================

library("tidyverse")
library("dplyr ")
library("tidyverse")




Poem_Tones_output1 <- ggscatter(subset(Poem_Tones_corr, Lines %in% c("Line 1", "Line 2", "Line 3", "Line 4")), x = "Speech", y = "Esa", 
                                add = "reg.line", add.params = list(color = "black", fill = "lightgray"), color = "lightgray", shape = 20, size = 2, conf.int = TRUE, 
                                cor.coef = FALSE, cor.method = "pearson", facet.by = "Lines",  short.panel.labs = TRUE,
                                xlab = "Speech", ylab = "Esa")+stat_cor(p.accuracy = 0.001, r.accuracy = 0.01, label.x = 90, label.y = 350)





Poem_Tones_output2 <- ggscatter(subset(Poem_Tones_corr, Lines %in% c("Line 1", "Line 2", "Line 3", "Line 4")), x = "Speech", y = "Ijala", 
                                add = "reg.line", add.params = list(color = "black", fill = "lightgray"), color = "lightgray", shape = 20, size = 2, conf.int = TRUE, 
                                cor.coef = FALSE, cor.method = "pearson", facet.by = "Lines",   short.panel.labs = TRUE,
                                xlab = "Speech", ylab = "Ijala")+stat_cor(p.accuracy = 0.001, r.accuracy = 0.01, label.x = 90, label.y = 300)






Poem_Tones_output3 <- ggscatter(subset(Poem_Tones_corr, Lines %in% c("Line 1", "Line 2", "Line 3", "Line 4")), x = "Ijala", y = "Esa", 
                                add = "reg.line", add.params = list(color = "black", fill = "lightgray"), color = "lightgray", shape = 20, size = 2, conf.int = TRUE, 
                                cor.coef = FALSE, cor.method = "pearson", facet.by = "Lines", short.panel.labs = TRUE,
                                xlab = "Ijala", ylab = "Esa")+stat_cor(p.accuracy = 0.001, r.accuracy = 0.01, label.x = 150, label.y = 300)




#============generate the correlation graph for===Mario vs Acappela===============================


#begin here for better resolution
tiff("cor_Speech_Esa.tiff", units="in", width=5, height=4, res=400)
#begin: insert ggplot code (this changes the solution to a better)


Poem_Tones_output1 


dev.off() 




#begin here for better resolution
tiff("cor_Speech_Ijala.tiff", units="in", width=5, height=4, res=400)
#begin: insert ggplot code (this changes the solution to a better)

Poem_Tones_output2


dev.off() 



#begin here for better resolution
tiff("cor_Ijala_Esa.tiff", units="in", width=5, height=4, res=400)
#begin: insert ggplot code (this changes the solution to a better)



Poem_Tones_output3


dev.off() 



#===================linear mixed effect================
library(emmeans)
library(nlme)
library(lme4)


View(Poem_Tonemes)
View(Poem_Intensity)
View(Poem_Tones)
View(Poem_Formants)

#linear mixed effect model stored in the object 'model with nlme
model_cpp <- lme(CPP ~ Vowels*Modes, random = ~1|Filename, data=Poem_Spectral)
model_Hammarberg <- lme(Hammarberg_index ~ Vowels*Modes, random = ~1|Filename, data=Poem_Spectral)
model_energy <- lme(energy_below_500Hz ~ Vowels*Modes, random = ~1|Filename, data=Poem_Spectral )
model_pitch25 <- lme(normF0_25 ~ Toneme*Modes, random = ~1|Vowels, data=Poem_Tonemes) #this will bring out error...
model_pitch50 <- lme(normF0_50 ~ Toneme*Modes, random = ~1|Vowels, data=Poem_Tonemes)#...as result of this all..
model_pitch75 <- lme(normF0_75 ~ Toneme*Modes, random = ~1|Vowels, data=Poem_Tonemes)#...all the data were subsetted. see https://stackoverflow.com/questions/50505290/singularity-in-backsolve-at-level-0-block-1-in-lme-model
model_intensity <- lme(mean_intensity ~ Vowel*Modes, random = ~1|Filename, data=Poem_Intensity)
model_f1 <- lme(F1_50 ~ Vowel*Modes, random = ~1|Filename, data=Poem_Formants)
model_f2 <- lme(F2_50 ~ Vowel*Modes, random = ~1|Filename, data=Poem_Formants)


#library(lme4) for linear mixed effect model when pairing is missing
LME_02<-lmer(normF_dispersion1_3 ~ Vowel*Tongue_Root + (1|Filename), na.action=na.exclude, data =Imilike_Praat_BIO2)






anova(model_cpp)
anova(model_Hammarberg)
anova(model_energy) 
anova(model_pitch25)
anova(model_pitch50) 
anova(model_pitch75)
anova(model_intensity) 
anova(model_f1)
anova(model_f2)




#===================linear mixed effect===with subsetting of data=============


#subsetting of data with diplyr 
H_Poem_Tonemes <- Poem_Tonemes %>% subset(Toneme == "H")
L_Poem_Tonemes <- Poem_Tonemes %>% subset(Toneme == "L")
M_Poem_Tonemes <- Poem_Tonemes %>% subset(Toneme == "M")

i_Poem_Formants <- Poem_Formants %>% subset(Vowel == "i")
u_Poem_Formants <- Poem_Formants %>% subset(Vowel == "u")
e_Poem_Formants <- Poem_Formants %>% subset(Vowel == "e")
o_Poem_Formants <- Poem_Formants %>% subset(Vowel == "o")
O_Poem_Formants <- Poem_Formants %>% subset(Vowel == "O")
E_Poem_Formants <- Poem_Formants %>% subset(Vowel == "E")
a_Poem_Formants <- Poem_Formants %>% subset(Vowel == "a")


i_Poem_Spectral <- Poem_Spectral %>% subset(Vowel == "i")
u_Poem_Spectral <- Poem_Spectral %>% subset(Vowel == "u")
e_Poem_Spectral <- Poem_Spectral %>% subset(Vowel == "e")
o_Poem_Spectral <- Poem_Spectral %>% subset(Vowel == "o")
O_Poem_Spectral <- Poem_Spectral %>% subset(Vowel == "O")
E_Poem_Spectral <- Poem_Spectral %>% subset(Vowel == "E")
a_Poem_Spectral <- Poem_Spectral %>% subset(Vowel == "a")



i_Poem_Intensity <- Poem_Intensity %>% subset(Vowel == "i")
u_Poem_Intensity <- Poem_Intensity %>% subset(Vowel == "u")
e_Poem_Intensity <- Poem_Intensity %>% subset(Vowel == "e")
o_Poem_Intensity <- Poem_Intensity %>% subset(Vowel == "o")
O_Poem_Intensity <- Poem_Intensity %>% subset(Vowel == "O")
E_Poem_Intensity <- Poem_Intensity %>% subset(Vowel == "E")
a_Poem_Intensity <- Poem_Intensity %>% subset(Vowel == "a")





#linear mixed effect model stored in the object 'model with nlme
H_model_F0_50 <- lme(normF0_50 ~ Modes, random = ~1|Vowels, data=H_Poem_Tonemes)
L_model_F0_50 <- lme(normF0_50 ~ Modes, random = ~1|Vowels, data=L_Poem_Tonemes)
M_model_F0_50 <- lme(normF0_50 ~ Modes, random = ~1|Vowels, data=M_Poem_Tonemes)


H_model_F0_25 <- lme(normF0_25 ~ Modes, random = ~1|Vowels, data=H_Poem_Tonemes)
L_model_F0_25 <- lme(normF0_25 ~ Modes, random = ~1|Vowels, data=L_Poem_Tonemes)
M_model_F0_25 <- lme(normF0_25 ~ Modes, random = ~1|Vowels, data=M_Poem_Tonemes)


H_model_F0_75 <- lme(normF0_75 ~ Modes, random = ~1|Vowels, data=H_Poem_Tonemes)
L_model_F0_75 <- lme(normF0_75 ~ Modes, random = ~1|Vowels, data=L_Poem_Tonemes)
M_model_F0_75 <- lme(normF0_75 ~ Modes, random = ~1|Vowels, data=M_Poem_Tonemes)




i_model_CPP <- lme(CPP ~ Modes, random = ~1|Filename, data=i_Poem_Spectral)
u_model_CPP <- lme(CPP ~ Modes, random = ~1|Filename, data=u_Poem_Spectral)
e_model_CPP <- lme(CPP ~ Modes, random = ~1|Filename, data=e_Poem_Spectral)
o_model_CPP <- lme(CPP ~ Modes, random = ~1|Filename, data=o_Poem_Spectral)
E_model_CPP <- lme(CPP ~ Modes, random = ~1|Filename, data=E_Poem_Spectral)
O_model_CPP <- lme(CPP ~ Modes, random = ~1|Filename, data=O_Poem_Spectral)
a_model_CPP <- lme(CPP ~ Modes, random = ~1|Filename, data=a_Poem_Spectral)

i_model_Hammarberg <- lme(Hammarberg_index ~ Modes, random = ~1|Filename, data=i_Poem_Spectral)
u_model_Hammarberg <- lme(Hammarberg_index ~ Modes, random = ~1|Filename, data=u_Poem_Spectral)
e_model_Hammarberg <- lme(Hammarberg_index ~ Modes, random = ~1|Filename, data=e_Poem_Spectral)
o_model_Hammarberg <- lme(Hammarberg_index ~ Modes, random = ~1|Filename, data=o_Poem_Spectral)
E_model_Hammarberg <- lme(Hammarberg_index ~ Modes, random = ~1|Filename, data=E_Poem_Spectral)
O_model_Hammarberg <- lme(Hammarberg_index ~ Modes, random = ~1|Filename, data=O_Poem_Spectral)
a_model_Hammarberg <- lme(Hammarberg_index ~ Modes, random = ~1|Filename, data=a_Poem_Spectral)


i_model_energy <- lme(energy_below_500Hz ~ Modes, random = ~1|Filename, data=i_Poem_Spectral)
u_model_energy <- lme(energy_below_500Hz ~ Modes, random = ~1|Filename, data=u_Poem_Spectral)
e_model_energy <- lme(energy_below_500Hz ~ Modes, random = ~1|Filename, data=e_Poem_Spectral)
o_model_energy <- lme(energy_below_500Hz ~ Modes, random = ~1|Filename, data=o_Poem_Spectral)
E_model_energy <- lme(energy_below_500Hz ~ Modes, random = ~1|Filename, data=E_Poem_Spectral)
O_model_energy <- lme(energy_below_500Hz ~ Modes, random = ~1|Filename, data=O_Poem_Spectral)
a_model_energy <- lme(energy_below_500Hz ~ Modes, random = ~1|Filename, data=a_Poem_Spectral)



i_model_intensity <- lme(mean_intensity ~ Modes, random = ~1|Filename, data=i_Poem_Intensity)
u_model_intensity <- lme(mean_intensity ~ Modes, random = ~1|Filename, data=u_Poem_Intensity)
e_model_intensity <- lme(mean_intensity ~ Modes, random = ~1|Filename, data=e_Poem_Intensity)
o_model_intensity <- lme(mean_intensity ~ Modes, random = ~1|Filename, data=o_Poem_Intensity)
E_model_intensity <- lme(mean_intensity ~ Modes, random = ~1|Filename, data=E_Poem_Intensity)
O_model_intensity <- lme(mean_intensity ~ Modes, random = ~1|Filename, data=O_Poem_Intensity)
a_model_intensity <- lme(mean_intensity ~ Modes, random = ~1|Filename, data=a_Poem_Intensity)




i_model_F1_50 <- lme(F1_50 ~ Modes, random = ~1|Filename, data=i_Poem_Formants)
u_model_F1_50 <- lme(F1_50 ~ Modes, random = ~1|Filename, data=u_Poem_Formants)
e_model_F1_50 <- lme(F1_50 ~ Modes, random = ~1|Filename, data=e_Poem_Formants)
o_model_F1_50 <- lme(F1_50 ~ Modes, random = ~1|Filename, data=o_Poem_Formants)
E_model_F1_50 <- lme(F1_50 ~ Modes, random = ~1|Filename, data=E_Poem_Formants)
O_model_F1_50 <- lme(F1_50 ~ Modes, random = ~1|Filename, data=O_Poem_Formants)
a_model_F1_50 <- lme(F1_50 ~ Modes, random = ~1|Filename, data=a_Poem_Formants)



i_model_F2_50 <- lme(F2_50 ~ Modes, random = ~1|Filename, data=i_Poem_Formants)
u_model_F2_50 <- lme(F2_50 ~ Modes, random = ~1|Filename, data=u_Poem_Formants)
e_model_F2_50 <- lme(F2_50 ~ Modes, random = ~1|Filename, data=e_Poem_Formants)
o_model_F2_50 <- lme(F2_50 ~ Modes, random = ~1|Filename, data=o_Poem_Formants)
E_model_F2_50 <- lme(F2_50 ~ Modes, random = ~1|Filename, data=E_Poem_Formants)
O_model_F2_50 <- lme(F2_50 ~ Modes, random = ~1|Filename, data=O_Poem_Formants)
a_model_F2_50 <- lme(F2_50 ~ Modes, random = ~1|Filename, data=a_Poem_Formants)





i_model_duration <- lme(Duration ~ Modes, random = ~1|Filename, data=i_Poem_Formants)
u_model_duration <- lme(Duration ~ Modes, random = ~1|Filename, data=u_Poem_Formants)
e_model_duration <- lme(Duration ~ Modes, random = ~1|Filename, data=e_Poem_Formants)
o_model_duration <- lme(Duration ~ Modes, random = ~1|Filename, data=o_Poem_Formants)
E_model_duration <- lme(Duration ~ Modes, random = ~1|Filename, data=E_Poem_Formants)
O_model_duration <- lme(Duration ~ Modes, random = ~1|Filename, data=O_Poem_Formants)
a_model_duration <- lme(Duration ~ Modes, random = ~1|Filename, data=a_Poem_Formants)


Vibrato_Vowel_duration <- lme(Duration ~ Modes, random = ~1|Filename, data=Poem_Tremor_Duration)




#running emmeans() for pairwise comparison
H_model_F0_50_results<- emmeans(H_model_F0_50, pairwise ~ Modes)
L_model_F0_50_results<- emmeans(L_model_F0_50 , pairwise ~ Modes)
M_model_F0_50_results<- emmeans(M_model_F0_50 , pairwise ~ Modes)

H_model_F0_25_results<- emmeans(H_model_F0_25, pairwise ~ Modes)
L_model_F0_25_results<- emmeans(L_model_F0_25 , pairwise ~ Modes)
M_model_F0_25_results<- emmeans(M_model_F0_25 , pairwise ~ Modes)


H_model_F0_75_results<- emmeans(H_model_F0_75, pairwise ~ Modes)
L_model_F0_75_results<- emmeans(L_model_F0_75 , pairwise ~ Modes)
M_model_F0_75_results<- emmeans(M_model_F0_75 , pairwise ~ Modes)




i_model_CPP_results<- emmeans(i_model_CPP, pairwise ~ Modes)
u_model_CPP_results<- emmeans(u_model_CPP, pairwise ~ Modes)
e_model_CPP_results<- emmeans(e_model_CPP, pairwise ~ Modes)
o_model_CPP_results<- emmeans(o_model_CPP, pairwise ~ Modes)
E_model_CPP_results<- emmeans(E_model_CPP, pairwise ~ Modes)
O_model_CPP_results<- emmeans(O_model_CPP, pairwise ~ Modes)
a_model_CPP_results<- emmeans(a_model_CPP, pairwise ~ Modes)



i_model_Hammarberg_results<- emmeans(i_model_Hammarberg, pairwise ~ Modes)
u_model_Hammarberg_results<- emmeans(u_model_Hammarberg, pairwise ~ Modes)
e_model_Hammarberg_results<- emmeans(e_model_Hammarberg, pairwise ~ Modes)
o_model_Hammarberg_results<- emmeans(o_model_Hammarberg, pairwise ~ Modes)
E_model_Hammarberg_results<- emmeans(E_model_Hammarberg, pairwise ~ Modes)
O_model_Hammarberg_results<- emmeans(O_model_Hammarberg, pairwise ~ Modes)
a_model_Hammarberg_results<- emmeans(a_model_Hammarberg, pairwise ~ Modes)


i_model_energy_results<- emmeans(i_model_energy, pairwise ~ Modes)
u_model_energy_results<- emmeans(u_model_energy, pairwise ~ Modes)
e_model_energy_results<- emmeans(e_model_energy, pairwise ~ Modes)
o_model_energy_results<- emmeans(o_model_energy, pairwise ~ Modes)
E_model_energy_results<- emmeans(E_model_energy, pairwise ~ Modes)
O_model_energy_results<- emmeans(O_model_energy, pairwise ~ Modes)
a_model_energy_results<- emmeans(a_model_energy, pairwise ~ Modes)


i_model_intensity_results<- emmeans(i_model_intensity, pairwise ~ Modes)
u_model_intensity_results<- emmeans(u_model_intensity, pairwise ~ Modes)
e_model_intensity_results<- emmeans(e_model_intensity, pairwise ~ Modes)
o_model_intensity_results<- emmeans(o_model_intensity, pairwise ~ Modes)
E_model_intensity_results<- emmeans(E_model_intensity, pairwise ~ Modes)
O_model_intensity_results<- emmeans(O_model_intensity, pairwise ~ Modes)
a_model_intensity_results<- emmeans(a_model_intensity, pairwise ~ Modes)


i_model_F1_50_results<- emmeans(i_model_F1_50, pairwise ~ Modes)
u_model_F1_50_results<- emmeans(u_model_F1_50, pairwise ~ Modes)
e_model_F1_50_results<- emmeans(e_model_F1_50, pairwise ~ Modes)
o_model_F1_50_results<- emmeans(o_model_F1_50, pairwise ~ Modes)
E_model_F1_50_results<- emmeans(E_model_F1_50, pairwise ~ Modes)
O_model_F1_50_results<- emmeans(O_model_F1_50, pairwise ~ Modes)
a_model_F1_50_results<- emmeans(a_model_F1_50, pairwise ~ Modes)


i_model_F2_50_results<- emmeans(i_model_F2_50, pairwise ~ Modes)
u_model_F2_50_results<- emmeans(u_model_F2_50, pairwise ~ Modes)
e_model_F2_50_results<- emmeans(e_model_F2_50, pairwise ~ Modes)
o_model_F2_50_results<- emmeans(o_model_F2_50, pairwise ~ Modes)
E_model_F2_50_results<- emmeans(E_model_F2_50, pairwise ~ Modes)
O_model_F2_50_results<- emmeans(O_model_F2_50, pairwise ~ Modes)
a_model_F2_50_results<- emmeans(a_model_F2_50, pairwise ~ Modes)



i_model_duration_results<- emmeans(i_model_duration, pairwise ~ Modes)
u_model_duration_results<- emmeans(u_model_duration, pairwise ~ Modes)
e_model_duration_results<- emmeans(e_model_duration, pairwise ~ Modes)
o_model_duration_results<- emmeans(o_model_duration, pairwise ~ Modes)
E_model_duration_results<- emmeans(E_model_duration, pairwise ~ Modes)
O_model_duration_results<- emmeans(O_model_duration, pairwise ~ Modes)
a_model_duration_results<- emmeans(a_model_duration, pairwise ~ Modes)



model_Vibrato_Vowel_duration_results<- emmeans(Vibrato_Vowel_duration, pairwise ~ Modes)




#Results
H_model_F0_50_results
L_model_F0_50_results
M_model_F0_50_results

H_model_F0_25_results
L_model_F0_25_results
M_model_F0_25_results


H_model_F0_75_results
L_model_F0_75_results
M_model_F0_75_results


i_model_CPP_results
u_model_CPP_results
e_model_CPP_results
o_model_CPP_results
E_model_CPP_results
O_model_CPP_results
a_model_CPP_results


i_model_Hammarberg_results
u_model_Hammarberg_results
e_model_Hammarberg_results
o_model_Hammarberg_results
E_model_Hammarberg_results
O_model_Hammarberg_results
a_model_Hammarberg_results


i_model_energy_results
u_model_energy_results
e_model_energy_results
o_model_energy_results
E_model_energy_results
O_model_energy_results
a_model_energy_results


i_model_intensity_results
u_model_intensity_results
e_model_intensity_results
o_model_intensity_results
E_model_intensity_results
O_model_intensity_results
a_model_intensity_results


i_model_F1_50_results
u_model_F1_50_results
e_model_F1_50_results
o_model_F1_50_results
E_model_F1_50_results
O_model_F1_50_results
a_model_F1_50_results


i_model_F2_50_results
u_model_F2_50_results
e_model_F2_50_results
o_model_F2_50_results
E_model_F2_50_results
O_model_F2_50_results
a_model_F2_50_results


i_model_duration_results
u_model_duration_results
e_model_duration_results
o_model_duration_results
E_model_duration_results
O_model_duration_results
a_model_duration_results



model_Vibrato_Vowel_duration_results
